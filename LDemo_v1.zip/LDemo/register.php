<?php
include 'header.php';

/* Ha lenyomtuk a bejelentkezés gombot - email + jelszó  ellenőrzése
 * Siker-> átirányítás a belső oldalra index2.php
 * Sikertelen -> hiba üzenet megjelenítése
 */
if (isset($_POST['register'])) {
    $email = $_POST['email'];
    echo $email;
    $jelszo = password_hash($_POST['jelszo'], PASSWORD_DEFAULT);
    $felhasznalonev = $_POST['felhasznalonev'];

    $sql = "SELECT * FROM felhasznalok WHERE email = '$email';";
    $result = $db->RunSQL($sql);
    $chk_email = $result->fetch_assoc();

    $sql = "SELECT * FROM felhasznalok WHERE felhasznalonev = '$felhasznalonev';";
    $result = $db->RunSQL($sql);
    $chk_user = $result->fetch_assoc();

    if ($chk_email != false) {
        echo '<div class="alert alert-danger text-center" role="alert">Ezzel az email címmel'
        . 'már regisztráltak! <br><strong>Próbálkozzon újra</strong></div>';
    } elseif ($chk_user != false) {
        echo '<div class="alert alert-danger text-center" role="alert"> az email cím megfelelő, de az afelhasznaló név már foglalt '
        . '<br><strong>Próbálkozzon újra</strong></div>';
    } else {
        $sql = "INSERT INTO felhasznalok VALUES ('null', '$felhasznalonev', '$email', '$jelszo','" . date("Y-m-d H:i:s") . "');";
        $result = $db->RunSQL($sql);
        echo '<div class="alert alert-succes text-center" role="alert"> A regisztráció sekeres! '
        . '<br><strong>Jelentkezz be!</strong></div>';
        header('Location: login.php');
    }
}
?>

<div class="row">
    <main>
        <article class="d-flex flex-wrap" >
            <div class="col-6 offset-3 my-3">
                <div class="card mb-3 text-center h-100 mx-2">
                    <img class='card-img-top w-25 mx-auto '  src="img/user.png"  alt="...">
                    <div class="card-body">
                        <form method="POST" >
                            <div class="mb-3">
                                <label for="felhasznalonev" class="form-label">Felhasználónév</label>
                                <input type="text" class="form-control" id="felhasznalonev" name="felhasznalonev" >
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email cím</label>
                                <input type="email" class="form-control" id="email" name="email" >
                            </div>
                            <div class="mb-3">
                                <label for="jelszo" class="form-label">Jelszó</label>
                                <input type="password" class="form-control" id="jelszo" name="jelszo">
                            </div>
                            <button type="submit" class="btn btn-secondary my-3" id="register" name="register" >Regisztráció</button>
                            <div class="d-flex justify-content-around" >
                                <a  class="" href="index.php" >Mégsem</button></a>
                            </div>
                        </form>
                    </div>

                </div>
            </div>

    </main>
</div>

<?php
include 'footer.php';
?>