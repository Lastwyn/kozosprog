<?php
include 'header.php';

/* Ha lenyomtuk a bejelentkezés gombot - email + jelszó  ellenőrzése
 * Siker-> átirányítás a belső oldalra index2.php
 * Sikertelen -> hiba üzenet megjelenítése
 */
if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $jelszo = $_POST['jelszo'];

    $sql = "SELECT * FROM felhasznalok WHERE email = '$email';";
    $result = $db->RunSQL($sql);
    $user = $result->fetch_assoc();

    if ($user != false && password_verify($jelszo, $user['jelszo'])) {
        $_SESSION['email'] = $user['email'];
        $_SESSION['felhasznalonev'] = $user['felhasznalonev'];
        header('Location: index2.php');
    } else {
        echo '<div class="alert alert-danger text-center" role="alert">A felhasznaló név '
        . ' és/vagy a jelszó nem megfelelő <br><strong>Próbálkozzon újra</strong></div>';
    }
}
?>

<div class="row">
    <main>
        <article class="d-flex flex-wrap" >
            <div class="col-6 offset-3 my-3">
                <div class="card mb-3 text-center h-100 mx-2">
                    <img class='card-img-top w-25 mx-auto '  src="img/user.png"  alt="...">
                    <div class="card-body">
                        <form method="POST" >
                            <div class="mb-3">
                                <label for="email" class="form-label">Email cím</label>
                                <input type="email" class="form-control" id="email" name="email" >
                            </div>
                            <div class="mb-3">
                                <label for="jelszo" class="form-label">Jelszó</label>
                                <input type="password" class="form-control" id="jelszo" name="jelszo">
                            </div>
                            <button type="submit" class="btn btn-secondary m-3" id="login" name="login" >Bejelentkezés</button>
                            <div class="d-flex justify-content-around" >
                                <a  class="" href="register.php" >Regisztráció</button></a>
                                <a  class="" Href="forgotpass.php" >Elfelejtett Jelszó</a>
                            </div>


                        </form>
                    </div>

                </div>
            </div>

    </main>
</div>

<?php
include 'footer.php';
?>