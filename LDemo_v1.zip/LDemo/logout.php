<?php

/*
 * Minden regisztrált session változó megszüntetése
 * visszairányítása a külső oldalra
 */
session_start();
session_destroy();
header('Location: index.php');
