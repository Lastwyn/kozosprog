<div class = "row">
    <footer>
        <h4>Mekk Elek &COPY; 2023</h4>
    </footer>
</div>
<!--konténer zárása-->
</div>



<script src = "kozos/all.min.js" type = "text/javascript"></script>
<script src="kozos/fontawesome.min.js" type="text/javascript">
</script> <script src="kozos/bootstrap.min.js" type="text/javascript"></script>

</body>
</html>


