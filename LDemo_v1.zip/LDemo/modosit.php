<?php
include 'header.php';

if (isset($_POST['modosit'])) {

    array_pop($_POST);
    extract($_POST);

    $sql = "UPDATE alkatreszek SET ";
    foreach ($_POST as $key => $value) {
        if ($key != 'id') {
            $sql .= $key . "='" . $value . "', ";
        }
    }
    $sql = substr($sql, 0, strlen($sql) - 2);
    $sql .= " WHERE id = '$id';";
    //echo $sql;
    $result = $db->RunSQL($sql);
    header('Location: index2.php');
} else {
    $sql = "SELECT * FROM alkatreszek WHERE id='" . $_GET['id'] . "';";
    $result = $db->RunSQL($sql);
    $row = $result->fetch_assoc();
}


if (isset($_POST['megsem'])) {
    header('Location: index2.php');
}
?>

<div class="row">
    <main>
        <article class="d-flex flex-wrap" >
            <div class="col-6 offset-3 my-3">
                <div class="card mb-3 text-center h-100 mx-2">
                    <img class='card-img-top w-50 mx-auto '  src="img/<?= $row['kep']; ?>"  alt="...">
                    <div class="card-body">
                        <form method="POST">
                            <?php foreach ($row as $key => $value) : ?>
                                <div class="mb-2 text-start" >
                                    <label for="<?= $key; ?>" class="form-label"><strong><?= $key; ?></strong></label>
                                    <input class="form-control" type="text" name="<?= $key; ?>" id="<?= $key; ?>" value="<?= $value; ?>" >
                                </div>
                            <?php endforeach; ?>
                    </div>
                    <button class="btn btn-secondary mb-3 mx-1 " type="submit" name="modosit" >Módosít</button>
                    <button class="btn btn-secondary mb-1 mx-1" type="submit" name="megsem" >Mégsem</button>
                    </form>
                </div>
            </div>

        </article>
    </main>
</div>

<?php
include 'footer.php';
?>