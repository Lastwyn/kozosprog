<?php
include_once 'header.php';
?>

<div class="row bg-dark h-100">
    <main class="h-100">
        <article class="d-flex flex-wrap" >
            <?php while ($row = $result->fetch_assoc()) : ?>
                <div class="col-sm-12 col-md-6 col-lg-4 col-xl-3 my-3">
                    <div class="card mb-3 text-center h-100 mx-2">
                        <img class='card-img-top w-50 mx-auto '  src="img/<?= $row['kep']; ?>"  alt="...">
                        <div class="card-body">
                            <h5 class="card-title"><?= $row['alkatresz_neve']; ?></h5>
                            <p class="card-text"><strong>nettó ár: </strong><?= $row['netto_ar'] ?>  Ft </p>
                        </div>
                        <a class="btn btn-secondary mb-3" href="index2.php?id=<?= $row['id']; ?>&torol=igen" role="button">Töröl</a>
                        <a class="btn btn-secondary mb-3" href="modosit.php?id=<?= $row['id']; ?>" role="button">Szerkeszt</a>
                        <a class="btn btn-secondary mb-1" href="index2.php?cikkszam=<?= $row['cikkszam']; ?>" role="button">Kosárba rak</a>

                    </div>
                </div>
            <?php endwhile; ?>
        </article>
    </main>
</div>

<?php
include 'footer.php';
?>