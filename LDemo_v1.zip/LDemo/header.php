<!DOCTYPE html>
<?php
include 'kozos/adatbazis.php';
$db = new Database();
session_start();

if (isset($_GET['cikkszam']) && $_GET['cikkszam'] != "") {
    $cikkszam = $_GET['cikkszam'];

    $sql = "SELECT * FROM  alkatreszek WHERE cikkszam ='$cikkszam'; ";
    $result = $db->RunSQL($sql);
    $row = $result->fetch_assoc();

    $alkatresz_neve = $row['alkatresz_neve'];
    $cikkszam = $row['cikkszam'];
    $netto_ar = $row['netto_ar'];
    $kep = $row['kep'];

    $kosarTomb = array(
        $cikkszam => array(
            'alkatresz_neve' => $alkatresz_neve,
            'cikkszam' => $cikkszam,
            'netto_ar' => $netto_ar,
            'darab' => 1,
            'kep' => $kep)
    );

    if (empty($_SESSION["kosar"])) {
        $_SESSION["kosar"] = $kosarTomb;
//        echo '<div class="alert alert-success text-center alert-dismissible fade show" role="alert">
//                A terméket sikeresen hozzáadtuk a kosárhoz <button type="button" class="btn-close"
//                data-bs-dismiss="alert" aria-label="Close"></button></div>';
    } else {
        $array_keys = array_keys($_SESSION["kosar"]);
        if (in_array($cikkszam, $array_keys)) {

//            echo '<div class="alert alert-danger text-center alert-dismissible fade show" role="alert">
//               A termék már a kosárban van! <button type="button" class="btn-close"
//                data-bs-dismiss="alert" aria-label="Close"></button></div>';
        } else {
            $_SESSION["kosar"] = array_merge(
                    $_SESSION["kosar"],
                    $kosarTomb
            );

//            echo '<div class="alert alert-success text-center alert-dismissible fade show" role="alert">
//                A terméket sikeresen hozzáadtuk a kosárhoz <button type="button" class="btn-close"
//                data-bs-dismiss="alert" aria-label="Close"></button></div>';
        }
    }
}


$keresoszo = isset($_GET['keres']) ? $_GET['keres'] : "";

if (isset($_GET['kereses']) && $_GET['keres'] != "") {
    $sql = "SELECT * FROM alkatreszek WHERE alkatresz_neve LIKE '%" . $keresoszo . "%';";
} else {
    $sql = "SELECT * FROM alkatreszek ; ";
}
$result = $db->RunSQL($sql);

if (isset($_SESSION['felhasznalonev'])) {
    if (isset($_GET['torol'])) {
        $sql = "DELETE FROM alkatreszek WHERE id=" . $_GET['id'] . ";";
        $db->RunSQL($sql);
        header('Location: index2.php');
    }
}
?>



<html lang="hu">
    <head>
        <meta charset="UTF-8">
        <title>Login demo</title>
        <link href="kozos/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="kozos/all.min.css" rel="stylesheet" type="text/css"/>
        <link href="kozos/sajat.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <header class="container-fluid" >
                    <div col-12>
                        <img class="w-100" src="img/fejlec.png" alt="fejlec"/>
                    </div>
                </header>
                <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
                    <div class="container-fluid">
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <a class="navbar-brand" href="<?= isset($_SESSION['felhasznalonev']) ? 'index2.php' : 'index.php'; ?>"> Autóalkatrészek</a>
                        <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
                            <form class="d-flex" role="search">
                                <input class="form-control me-2" type="search" placeholder="" aria-label="Search" name="keres">
                                <button class="btn btn-outline-light" name="kereses" type="submit" value="keres">Keres</button>
                            </form>
                            <?php if (isset($_SESSION['felhasznalonev'])) : ?>
                                <a class="btn btn-outline-light ms-3" href="logout.php" role="button">Kijelentkezés ( <?= $_SESSION['felhasznalonev']; ?> )</a>
                            <?php else: ?>
                                <a class="btn btn-outline-light ms-3" href="login.php" role="button">Bejelentkezés</a>
                            <?php endif; ?>

                            <?php if (!empty($_SESSION['kosar'])) : ?>
                                <a href="kosar.php" class="btn btn-outline-light ms-3  ">
                                    Kosár <span class="badge text-bg-secondary"><?= count(array_keys($_SESSION['kosar'])) ?></span>
                                </a>
                            <?php endif; ?>


                        </div>
                    </div>
            </div>
        </nav>






