<?php
include 'header.php';

$sql = "SELECT * FROM alkatreszek WHERE id=" . $_GET['id'] . ";";
$result = $db->RunSQL($sql);
$row = $result->fetch_assoc();
?>

<div class="row ">
    <main class="h-100">
        <article class="d-flex flex-wrap" >

            <div class="col-6 offset-3 my-3">
                <div class="card mb-3 text-center h-100 mx-2">
                    <img class='card-img-top w-50 mx-auto '  src="img/<?= $row['kep']; ?>"  alt="...">
                    <div class="card-body">
                        <h5 class="card-title"><?= $row['alkatresz_neve']; ?></h5>
                        <?php foreach ($row as $key => $value) : ?>
                            <p class = "card-text"><strong><?= $key; ?>:</strong> <?= $value; ?> </p>
                        <?php endforeach; ?>


                    </div>
                    <a class="btn btn-secondary" href="index2.php" role="button">Vissza</a>
                </div>
            </div>

        </article>
    </main>
</div>

<?php
include 'footer.php';
?>