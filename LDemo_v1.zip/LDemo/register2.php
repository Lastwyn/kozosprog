<?php
include "kozos/header_1.php";

if (isset($_POST['reg'])) {
    $fn = $_POST['fullname'];
    $em = $_POST['email'];
    $un = $_POST['username'];
    $pw = password_hash($_POST['password'], PASSWORD_DEFAULT); //jelszó kivonat (hash) létrehozása bcrypt algoritmussal 
    $tp = $_POST['type'];
    $hash = md5(rand(0, 1000)); //md5 kivonat készítése a regisztráció ellenőrzéséhez
    try {
        $stmt = $adatbazisom->prepare("INSERT INTO users VALUES('',?,?,?,?,?,'0',?)");
        $stmt->bindParam(1, $fn);
        $stmt->bindParam(2, $em);
        $stmt->bindParam(3, $un);
        $stmt->bindParam(4, $pw);
        $stmt->bindParam(5, $tp);
        $stmt->bindParam(6, $hash);

        if ($stmt->execute()) {
            $to = $em;
            $subject = 'Regisztráció ellenőrzésés  bejelentkezés';
            $message = '

	    Köszönjük, hogy feliratkoztál!
            A fiók létrehozása után bejelentkezhetsz a következő hitelesítő adatokkal, miután aktiváltad fiókod az alábbi url-re kattintva.
			
            ------------------------
	    Felhasználói név: ' . $un . '
            jelszó: ' . $_POST['password'] . '
            ------------------------

            A fiók aktiválásához kattintson erre a linkre:
            http://localhost/webshop_kialakitasa/index.php?email=' . $em . '&hash=' . $hash . '

            ';

            $headers = 'From:admin@localhost' . "\r\n";

            
               mail($to, $subject, body_convert_hun($message), $headers);
            
            
                  

            echo '<div class="alert alert-success" role="alert">E-mailt küldtünk a fiókod aktiváláshoz, kérjlek, kattints vagy másold az e-mail címét a böngésző címsorába</div>';
        } else {
            echo '<div class="alert alert-danger" role="alert">Regisztrálási hiba, kérlek próbálkozz újra!</div>';
                     
                       
            $row = $stmt->fetch(); 
            $hash = $row['password'];
            //$password = $_POST['password'];
            $user = $row['username'];
            $full = $row['fullname'];
            $type = $row['type'];
            $act = $row['active'];
            if (password_verify($password, $hash)) {
                if ($act == '1') {
                    echo '<div class="alert alert-danger" role="alert">A jelszó nem megfelelő</div>';
                    session_start();
                    $_SESSION['username'] = $user;
                    $_SESSION['fullname'] = $full;
                    $_SESSION['type'] = $type;
                    ?>
                    <script>location.href = "admin/index.php"</script>
                    <?php
                } else {
                    echo '<div class="alert alert-warning" role="alert">A fiók nem aktív, kérjük, nyissa meg az e-mail bejövő fiókját, és kattintson az aktiválás linkjére.</div>';
                }
            }
        }
    } catch (PDOException $e) {
        echo 'Hiba: ' . $e->getMessage() . "." . $e->getTraceAsString() . "\n";
    }
}
?>
<div class="panel panel-default" style="margin-top:80px;">
    <div class="panel-body">
        <h3 class="text-center" style="font-weight:bolder;margin:10px 0;">Regisztráció</h3>
        <form method="post">
            <div class="form-group">
                <label for="fullname">Teljes név</label>
                <input type="text" id="fullname" name="fullname" class="form-control" placeholder="Teljes név" required/>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" class="form-control" placeholder="Email" required/>
            </div>
            <div class="form-group">
                <label for="username">Felhasználói név</label>
                <input type="text" id="username" name="username" class="form-control" placeholder="Felhasználói név" required/>
            </div>
            <div class="form-group">
                <label for="password">Jelszó</label>
                <input type="password" id="password" name="password" class="form-control" placeholder="Jelszó" required/>
            </div>
            <div class="form-group">
                <label for="type">Felhasználói típus</label>
                <select id="type" name="type" class="form-control">
                    
                    <option>Felhasználó</option>
                </select>
            </div>
            <button type="submit" name="reg" class="btn btn-primary btn-block">Regisztráció</button>
            <p style="clear:both;">
            <div style="float:left;"></div>
            <div style="float:right;"><a href="index.php">Bejelentkezés</a></div>
            </p>
        </form>
    </div>
</div>
<?php
include "kozos/footer.php";
?>