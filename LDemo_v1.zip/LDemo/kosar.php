<?php
include_once 'header.php';
if (isset($_POST['muvelet']) && $_POST['muvelet'] == "torol") {
    if (!empty($_SESSION["kosar"])) {
        foreach ($_SESSION["kosar"] as $key => $value) {
            if ($_POST["cikkszam"] == $key) {
                unset($_SESSION["kosar"][$key]);
            }
            if (empty($_SESSION["kosar"]))
                unset($_SESSION["kosar"]);
        }
    }
}

if (isset($_POST['muvelet']) && $_POST['muvelet'] == "modosit") {
    foreach ($_SESSION["kosar"] as &$value) {
        if ($value['cikkszam'] === $_POST["cikkszam"]) {
            $value['darab'] = $_POST["darab"];
            break; // kilepünk ha megtaláltuk a terméket
        }
    }
}
?>

<main class="  d-flex flex-column  align-content-stretch ">
    <div class="tablazat">
        <?php
        if (isset($_SESSION["kosar"])) {
            $osszes_ar = 0;
            $darab = 0;
            ?>
            <table class=" table table-striped-columns m-3 text-center w-75 mx-auto ">
                <tbody>
                    <tr>
                        <th>Cikkszám</th>
                        <th>Kép</th>
                        <th>Megnevezés</th>
                        <th>Darab</th>
                        <th>Egységár</th>
                        <th>Összár</th>
                        <th></th>
                    </tr>


                    <?php foreach ($_SESSION["kosar"] as $key => $product) : ?>
                        <tr>
                            <td><?= $key; ?></td>
                            <td>
                                <img src='img/<?= $product["kep"]; ?>' width="50" height="40" />
                            </td>
                            <td><?= $product["alkatresz_neve"]; ?> </td>
                            <td>
                                <form method='post' action=''>
                                    <input type='hidden' name='cikkszam' value="<?= $product["cikkszam"]; ?>" />
                                    <input type='hidden' name='muvelet' value="modosit" />
                                    <input type="number" name="darab" class="darab" value="<?= $product['darab'] ?>" onchange="this.form.submit()" style="width:40px; text-align: center;" />
                                </form>
                            </td>
                            <td><?= $product["netto_ar"] . " Ft"; ?></td>
                            <td><?= $product["netto_ar"] * $product["darab"] . " Ft"; ?></td>
                            <td>
                                <form method='post' action=''>
                                    <input type='hidden' name='cikkszam' value="<?= $product["cikkszam"]; ?>" />
                                    <input type='hidden' name='muvelet' value="torol" />
                                    <button type='submit' class="btn btn-outline-dark"'>Töröl</button>
                                </form>
                            </td>
                        </tr>
                        <?php
                        $osszes_ar += ($product["netto_ar"] * $product["darab"]);
                    endforeach;
                    ?>

                    <tr>
                        <td colspan="6" align="right">
                            <strong>TOTAL: <?= $osszes_ar . " Ft"; ?></strong>
                        </td>
                        <td></td>
                    </tr>
                </tbody>
            </table>
            <?php
        } else {
            echo "<h3>A kosara üres!</h3>";
        }
        ?>
    </div>
    <div class="text-center m-3 ">
        <a href="<?= isset($_SESSION['felhasznalonev']) ? 'index2.php' : 'index.php'; ?>" class="btn btn-outline-dark"> A vásárlás folytatása</a>
    </div>
    <div class="text-center m-3">
        <?php if (isset($_SESSION['felhasznalonev'])) : ?>
            <a href="fizetes.php" class="btn btn-outline-dark">Tovább a fizetéshez</a>
        <?php else : ?>
            <div class="alert alert-info text-center alert-dismissible fade show" role="alert">
                Még nem jelentkezett be! Jelentkezzen be! <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>';
            <?php endif; ?>

    </div>

</main>

<?php
include_once 'footer.php';
?>




