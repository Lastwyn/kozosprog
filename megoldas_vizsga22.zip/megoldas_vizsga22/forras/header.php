<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap.min.css"> 
    <link rel="stylesheet" href="bootstrap-icons.css">
    <link rel="stylesheet" href="stilus.css">

    <title>Vizsga 2023</title>
</head>
<?php 
include('adatbazis.php');
$db = new Database();
?>
