<?php
include('header.php');

$search = isset($_GET['searchbox']) ? $_GET['searchbox'] : "";
if (isset($_GET['search']) && $_GET['searchbox'] != ""){
    $sql = "SELECT * FROM varosok WHERE varos LIKE '%".$search."%';";
    
}else {
   $sql =  "SELECT * FROM varosok;";
}
$result = $db->RunSQL($sql);
?>

<body>
    <header >
        <img class="w-100" src="img/fejlec.png" alt="">
        <nav class="navbar">
            <h4 class="float-left m-2 ">Eurázsiai városok</h4>
          
            <form class="form-inline float-right ">
                <input class=" nav-item form-control mr-sm-2" type="search" name="searchbox" placeholder="Keresés">
                <button class="nav-item btn btn-outline-success btn-outline-light m-2" type="submit" name="search">Keresés</button>  
                <button type="submit" class="nav-item btn btn-outline-light m-2">Bejelentkezés</button>
            </form>
        </nav>
    </header>
    <main>
        <?php while ($row = $result->fetch_assoc()) : ?>
        <div class="card" style="width: 18rem;">
            <img src="img/<?= $row['kep'];?>" class="card-img-top" alt="<?= $row['varos'];?>">
            <div class="card-body">
                <h5 class="card-title" a href="index2.php"><?= $row['varos'];?></a></h5>
            </div>
            <?php endwhile;?>
    </main>
