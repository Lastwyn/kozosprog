<footer class="fixed-bottom">
           &copy Sőregi Dávid - 2023
    </footer>
</body>
<script src="bootstrap.min.js"></script>
</html>